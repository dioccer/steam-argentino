function mostrarVideo() {
    document.getElementById('cat_j1').style.display='block';
}

function ocultarVideo() {
    document.getElementById('cat_j1').style.display='none';
}